<ol>
<?php foreach ($messages as $message): ?>
    <li><?= $message->message ?></li>
<?php endforeach ?>
</ol>
