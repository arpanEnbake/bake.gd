<?php

class Message extends Controller
{
    function Message()
    {
        parent::Controller();
        
        $this->load->model('Message_model');
    }
    
    function index()
    {
        // redirect to view
        redirect('message/view');
    }
    
    function add()
    {
        // if HTTP POST is sent, add the data to database
        if($_POST && $_POST['message'] != NULL) {
            $message['message'] = $this->input->xss_clean($_POST['message']);
            $this->Message_model->add($message);
        } else
            redirect('message/view');
    }
    
    function view($type = NULL)
    {
        // get data from database
        $data['messages'] = $this->Message_model->get();
        
        if ($type == "ajax") // load ajax view
            $this->load->view('messages_list', $data);
        else // load the default view
            $this->load->view('default', $data);
    }
}

?>
